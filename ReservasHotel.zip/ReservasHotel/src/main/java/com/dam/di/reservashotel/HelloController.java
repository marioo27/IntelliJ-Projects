
package com.dam.di.reservashotel;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class HelloController {

    @FXML
    private Pane paneReporte;

    @FXML
    private Button btnVisualizarInforme, btnGuardarPDF;

    private Reporte reporte;

    public void initialize() {
        reporte = new Reporte();
    }

    @FXML
    private void mostrarReporte() {
        reporte.mostrarInforme(paneReporte);
    }

    @FXML
    private void exportarReporte() {
        reporte.exportarInforme("informes/informeHotel.pdf");
    }
}

